## Developed by Soumya Tejaswi Vadlamani and Sai Madhavi Gujju


import sys
import os
import socket
import json
import select
import time
import threading
import signal
import ipaddress
import copy

hostname_dict = dict()
routing_table_dict = dict()
interface_table_dict = dict()
ARP_cache = dict()
sock_dict = dict()
message_queue = list()
data = dict()
exit_event = threading.Event()


def signal_handler(sig, frame):
    try:
        exit_event.set()
        for key, socket1 in sock_dict.items():
            socket1.close()
        sys.exit(0)
    except Exception as e:
        pass


def time_thread_fun():
    try:
        while not exit_event.is_set():
            items = []
            ARP_cache1 = copy.copy(ARP_cache)
            for id, values in ARP_cache1.items():
                for key, value in values.items():
                    if key == 'time' and (time.time() - value) > 30.0:
                        items.append(id)
            for id in items:
                del ARP_cache[id]
            time.sleep(1)
    except Exception as e:
        pass


def to_find_next_hop(destination_ip):
    try:
        next_hop = ""
        next_destination = ''
        through_interface = ''
        ip_check = ipaddress.IPv4Address(destination_ip)
        for entry, objects in routing_table_dict.items():
            network_mask_dotted = routing_table_dict[entry]["network_mask"]
            prefix_check = ipaddress.ip_network((entry, network_mask_dotted), strict=False)
            if ip_check in prefix_check:
                if next_hop == "" or prefix_check.prefixlen > next_hop.prefixlen:
                    next_hop = prefix_check
                    next_destination = routing_table_dict[entry]["next_hop_ip"]
                    through_interface = routing_table_dict[entry]["network_interface"]
        if next_hop == '':
            next_destination = routing_table_dict['0.0.0.0']["next_hop_ip"]
            through_interface = routing_table_dict['0.0.0.0']["network_interface"]
        return next_destination, through_interface
    except Exception as e:
        pass


def to_send(eth_frame, forward_to, interface):
    try:
        if forward_to == '0.0.0.0':
            if eth_frame["destination_ip"] in ARP_cache:
                ## we also need to chage the source mac address before sending
                for id, values in interface_table_dict.items():
                    # to find the source we need to check the
                    if id == interface:
                        eth_frame["source_mac"] = interface_table_dict[id]["mac_address"]
                eth_frame["destination_mac"] = ARP_cache[eth_frame["destination_ip"]]["mac_address"]
                act_client = sock_dict[interface]
                eth_frame = json.dumps(eth_frame)
                eth_frame = "{}__END__".format(eth_frame)
                act_client.send(eth_frame.encode())
        if forward_to != '0.0.0.0':
            if forward_to in ARP_cache:
                eth_frame["destination_mac"] = ARP_cache[forward_to]["mac_address"]

                ## we also need to change the source mac address before sending
                for id, values in interface_table_dict.items():
                    # to find the source we need to check the
                    if id == interface:
                        eth_frame["source_mac"] = interface_table_dict[id]["mac_address"]
                act_client = sock_dict[interface]
                eth_frame = json.dumps(eth_frame)
                eth_frame = "{}__END__".format(eth_frame)
                act_client.send(eth_frame.encode())
    except Exception as e:
        pass


def ARP_request(eth_frame, interface, forward_to):
    try:
        data2 = dict()
        data2["type"] = "ARP_Request"
        data2["source_name"] = interface
        data2["source_mac"] = interface_table_dict[interface]["mac_address"]
        data2["source_ip"] = interface_table_dict[interface]["station_ip"]

        # data["destination_ip"]=eth_frame["destination_ip"]
        if forward_to == '0.0.0.0':
            data2["message"] = eth_frame["destination_ip"]
        if forward_to != '0.0.0.0':
            data2["message"] = forward_to
        act_client = sock_dict[interface]
        data2 = json.dumps(data2)
        data2 = "{}__END__".format(data2)
        act_client.send(data2.encode())
    except Exception as e:
        pass


def queue_threads():
    try:
        while not exit_event.is_set():
            for data1 in message_queue:
                forward_to, interface = to_find_next_hop(data1["destination_ip"])
                if forward_to == '0.0.0.0':
                    if data1['destination_ip'] in ARP_cache:
                        to_send(data1, forward_to, interface)
                        message_queue.remove(data1)
                    else:
                        ARP_request(data1, interface, forward_to)

                        # send arp request and put the message in the queue
                if forward_to != '0.0.0.0':
                    if forward_to in ARP_cache:
                        to_send(data1, forward_to, interface)
                        message_queue.remove(data1)
                    else:
                        ARP_request(data1, interface, forward_to)
                else:
                    pass
            time.sleep(1)
    except Exception as e:
        pass


def write_threads():
    try:
        while not exit_event.is_set():
            message = input()
            parts = message.split()
            if parts[0] == "send":
                parts = message.split()
                msg = " ".join(parts[2:])
                if parts[1] in hostname_dict:
                    destination_ip = hostname_dict[parts[1]]
                else:
                    print("Send the message in send <destination> <message> format")
                    exit(0)

                forward_to, interface = to_find_next_hop(destination_ip)
                # print("forward to is {} and interface is {}".format(forward_to, interface))
                data = dict()
                data["type"] = "Message"
                data["source_name"] = interface
                data["source_mac"] = interface_table_dict[interface]["mac_address"]
                data["source_ip"] = interface_table_dict[interface]["station_ip"]
                data["message"] = msg
                data["destination_ip"] = destination_ip
                data["next_hop"] = forward_to
                message_queue.append(data)
            elif message == "show arp":
                print("--------------------------------------------------------------------------------------------")
                for key, value in ARP_cache.items():
                    mac_address = ARP_cache[key]["mac_address"]
                    ti = ((time.time()) - ARP_cache[key]['time'])
                    print("{}--> mac_address:{} , time:{}".format(key, mac_address, ti))
                # print the arp cache table
                print("--------------------------------------------------------------------------------------------")
            elif message == "show pq":
                # print the message_queue
                print("--------------------------------------------------------------------------------------------")
                for value in message_queue:
                    print(value)
                print("--------------------------------------------------------------------------------------------")
            elif message == "show host":
                print("--------------------------------------------------------------------------------------------")
                for key, value in hostname_dict.items():
                    print("{}: {}".format(key, value))
                # print the host table
                print("--------------------------------------------------------------------------------------------")
            elif message == "show iface":
                print("--------------------------------------------------------------------------------------------")
                for key, value in interface_table_dict.items():
                    print("{}: {}".format(key, value))
                # print the interface table
                print("--------------------------------------------------------------------------------------------")
            elif message == "show rtable":
                print("--------------------------------------------------------------------------------------------")
                for key, value in routing_table_dict.items():
                    print("{}: {}".format(key, value))
                # print the routing table
                print("--------------------------------------------------------------------------------------------")
            elif message == "quit":
                exit_event.set()
                for key, value in sock_dict.items():
                    value.close()
                sys.exit(0)

                # close all the sockets and close the code
            else:
                print(
                    "Send the message in send <destination> <message> format, <show arp> to show the arp_cache table, <show pq> to show the pending message queue, <show host> to show the host table, <show iface> to show the interface table, <show rtable> to show the routing table,<quit> to close the station")
    except Exception as e:
        pass


def read_threads(client_socket):
    try:
        while not exit_event.is_set():
            lst = [client_socket]
            if client_socket.fileno() == -1:
                lst.remove(client_socket)
            else:
                read_sockets, _, _ = select.select(lst, [], [], 1)
                if client_socket in read_sockets:
                    # need to write according to delimiter
                    raw_data = client_socket.recv(1024)
                    if len(raw_data) > 0:
                        raw_data = raw_data.decode().split('__END__')
                        for data in raw_data:
                            if data.strip():
                                start_index = data.find('{')
                                data = data[start_index:]
                                data = data.strip().rstrip("__END__")
                                eth_frame = json.loads(data)
                                data1 = dict()
                                if eth_frame["type"] == "ARP_Request":
                                    for entry, objects in interface_table_dict.items():
                                        if eth_frame["message"] == interface_table_dict[entry]["station_ip"]:
                                            if eth_frame["source_ip"] not in ARP_cache:
                                                ARP_cache[eth_frame["source_ip"]] = {
                                                    "mac_address": eth_frame["source_mac"]}
                                                ARP_cache[eth_frame["source_ip"]]["time"] = time.time()
                                            else:
                                                ARP_cache[eth_frame["source_ip"]]["time"] = time.time()
                                            forward_to, interface = to_find_next_hop(eth_frame["source_ip"])
                                            data1["type"] = "ARP_Reply"
                                            data1["source_name"] = interface
                                            for id, values in interface_table_dict.items():
                                                # to find the source we need to check the
                                                if id == interface:
                                                    data1["source_mac"] = interface_table_dict[id]["mac_address"]
                                                    data1["source_ip"] = interface_table_dict[id]["station_ip"]

                                            data1["destination_ip"] = eth_frame["source_ip"]
                                            data1["destination_mac"] = eth_frame["source_mac"]

                                            act_client = sock_dict[interface]
                                            data1 = json.dumps(data1)
                                            data1 = "{}__END__".format(data1)
                                            act_client.send(data1.encode())

                                    # here once we got the arp request we need to take the message which contains the ip address and need to check if it is ours ip then we need to send our mac_address to the source ip: here the source ip means the stations ip which sends the arp request packet

                                elif eth_frame["type"] == "Message":
                                    for entry, objects in interface_table_dict.items():
                                        ## do i need to update the time of router in arp cache

                                        if eth_frame["destination_ip"] == interface_table_dict[entry]["station_ip"] and \
                                                eth_frame["destination_mac"] == interface_table_dict[entry][
                                            "mac_address"]:
                                            print("Message from {}: {}".format(eth_frame["source_name"],
                                                                               eth_frame["message"]))

                                            # we need to update the time in arp cache if receive the data from that station
                                            break
                                        if sys.argv[1] == '-route' and eth_frame["destination_mac"] == \
                                                interface_table_dict[entry][
                                                    "mac_address"]:
                                            forward_to, interface = to_find_next_hop(eth_frame["destination_ip"])
                                            eth_frame["next_hop"] = forward_to

                                            ## we need to update the time of the mac address of the sender (as we get the senders mac )
                                            message_queue.append(eth_frame)
                                        else:
                                            pass
                                elif eth_frame["type"] == "ARP_Reply":
                                    # print("the reply we got is {}".format(eth_frame))
                                    for entry, objects in interface_table_dict.items():
                                        if eth_frame["destination_ip"] == interface_table_dict[entry]["station_ip"]:
                                            ARP_cache[eth_frame["source_ip"]] = {"mac_address": eth_frame["source_mac"]}
                                            ARP_cache[eth_frame["source_ip"]]["time"] = time.time()

                    else:
                        print("connection is closed")
                        client_socket.close()
                        lst = []
                        for key, value in sock_dict.items():
                            if value == client_socket:
                                lst.append(key)
                        for key in lst:
                            del sock_dict[key]
                        #client_socket.close()
                        if len(sock_dict) == 0:
                            exit_event.set()
                            sys.exit(0)

    except Exception as e:
        pass


def main():
    global client_socket, read_thread
    count = 0
    entry = 0
    if len(sys.argv) == 5:
        try:
            with open(sys.argv[4], 'r') as file:
                for line in file:

                    hostname, ip_address = line.split()
                    if len(line.split()) == 2:
                        hostname_dict[hostname] = ip_address
                    else:
                        print("Please provide all the details in the host file")
                        sys.exit(0)

        except Exception as e:
            pass
        with open(sys.argv[3], 'r') as file:
            for line in file:
                destination_ip_prefix, next_hop_ip, network_mask, network_interface = line.split()
                if len(line.split()) == 4:
                    routing_table_dict[destination_ip_prefix] = {"next_hop_ip": next_hop_ip,
                                                                 "network_mask": network_mask,
                                                                 "network_interface": network_interface}
                else:
                    print("Please provide all the details in routing file")
                    sys.exit(0)
        try:
            with open(sys.argv[2], 'r') as file:
                for line in file:

                    station_name, station_ip, station_network_mask, mac_address, lan_name = line.split()
                    if len(line.split()) == 5:
                        interface_table_dict[station_name] = {"station_ip": station_ip,
                                                              "station_network_mask": station_network_mask,
                                                              "mac_address": mac_address, "lan_name": lan_name}

                    else:
                        print("please provide all the details in the interface table")
                        sys.exit(0)
        except Exception as e:
            pass

        for id, value in interface_table_dict.items():
            file_name_ip = "." + interface_table_dict[id]["lan_name"] + ".addr"
            file_name_port = "." + interface_table_dict[id]["lan_name"] + ".port"
            try:
                with open(file_name_ip, 'r') as file:
                    lan_ip = file.read()
            except Exception as e:
                print("an error occurred: {}".format(e))
            try:
                with open(file_name_port, 'r') as file:
                    lan_port = int(file.read())
            except Exception as e:
                print("an error occurred: {}".format(e))
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

            try:
                signal.signal(signal.SIGINT, signal_handler)
                client_socket.connect((lan_ip, lan_port))
                client_socket.setblocking(True)
                for i in range(5):
                    reply = client_socket.recv(1024).decode()
                    print("the reply from server is {}".format(reply))
                    count += 1
                    if reply == 'accept':
                        client_socket.setblocking(False)
                        sock_dict[id] = client_socket
                        read_thread = threading.Thread(target=read_threads, args=(client_socket,))
                        # read_thread.daemon = True
                        read_thread.start()
                        # read_thread.join()
                        print("connection established")

                        break
                    elif reply == 'reject' or count > 5:
                        print("connection not established for {}".format(interface_table_dict[id]["lan_name"]))
                        client_socket.close()
                        # sys.exit(0)
                    else:
                        time.sleep(2)

            except Exception as e:
                print("an error occurred in the blocking: {}".format(e))
                sys.exit(0)
        write_thread = threading.Thread(target=write_threads)
        queue_thread = threading.Thread(target=queue_threads)
        time_thread = threading.Thread(target=time_thread_fun)
        write_thread.daemon = True
        queue_thread.daemon = True
        time_thread.daemon = True
        queue_thread.start()
        write_thread.start()
        time_thread.start()
        read_thread.join()
        #queue_thread.join()
        #write_thread.join()
        time_thread.join()
        if exit_event.is_set():
            sys.exit(0)


    else:
        print("please provide all the required arguments")


if __name__ == "__main__":
    main()
