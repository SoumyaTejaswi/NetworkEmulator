## Developed by Soumya Tejaswi Vadlamani and Sai Madhavi Gujju


import sys
import os
import socket
import select
import json
import time
import threading
import signal
import copy

sockets = []
mac_mapping = dict()
server_socketlst = []
ports = 0
exit_event = threading.Event()
server_ip = ''
server_port = ''
source_ip = ''
source_port = ''


def accept_thread(server_socket):
    global ports
    try:
        while not exit_event.is_set():
            try:
                read_sockets, _, _ = select.select([server_socket], [], [], 1)
                for reading_socket in read_sockets:
                    if reading_socket == server_socket:
                        client_socket, client_address = server_socket.accept()  # client_socket is a object
                        # client_socket=client_sockets.fileno()
                        #print("num_ports{}".format(num_ports))
                        if ports < num_ports:
                            client_ip, client_port = client_address
                            sockets.append(client_socket)
                            print("accept")
                            client_socket.send("accept".encode())
                            reading_thread = threading.Thread(target=read_thread, args=(client_socket,))
                            reading_thread.daemon = True
                            reading_thread.start()
                            # reading_thread.join()

                            ports += 1
                            #print("number of ports in accepting {}".format(ports))
                            # need to use time not count

                        else:
                            client_socket.send("reject".encode())
                            client_socket.close()
            except socket.error as e:
                print("socket closed")
    except Exception as e:
        pass


def read_thread(client_socket):
    global ports
    try:
        while not exit_event.is_set():
            read_sockets, _, _ = select.select(sockets, [], [], 1)
            if client_socket in read_sockets:
                eth_frame = client_socket.recv(1024)

                if len(eth_frame) > 0:
                    # we got the data then we need to decode it and do the required mac mapping
                    raw_data = eth_frame.decode().split('__END__')
                    for datas in raw_data:
                        if datas.strip():
                            start_index = datas.find('{')
                            datas = datas[start_index:]
                            datas = datas.strip().rstrip("__END__")
                            data = json.loads(datas)
                            mac_mapping[client_socket] = {"mac_address": data['source_mac'],
                                                          "time": time.time()}
                            if data['type'] == 'Message':
                                count = 0
                                data2 = copy.copy(data)
                                data2 = json.dumps(data2)
                                data2 = "{}__END__".format(data2)

                                for client_socket1, values1 in mac_mapping.items():

                                    if mac_mapping[client_socket1]["mac_address"] == data['destination_mac']:
                                        client_socket1.send(data2.encode())
                                        count = 1

                                        # mac_mapping[reading_socket]["mac_address"] = data['source_mac']
                                if count == 0:

                                    for sock in sockets:
                                        if sock != client_socket:
                                            sock.send(data2.encode())
                                    # if we dont have the mac addr then we need to broad cast  using the sockets list  the msg to all the stations in the server(bridge)
                                    # mac_mapping[reading_socket]["mac_address"] = data['source_mac']
                                    # send the data
                            elif data['type'] == 'ARP_Request':
                                data = json.dumps(data)
                                data = "{}__END__".format(data)
                                for sock in sockets:
                                    if sock != client_socket:
                                        sock.send(data.encode())

                            elif data['type'] == 'ARP_Reply':
                                # print("the mac_mapping dict is {}".format(mac_mapping))
                                for id, values1 in mac_mapping.items():
                                    if mac_mapping[id]["mac_address"] == data['destination_mac']:
                                        data1 = copy.copy(data)
                                        data1 = json.dumps(data1)
                                        data1 = "{}__END__".format(data1)
                                        id.send(data1.encode())
                                        # print("the reply sock is {}".format(mac_mapping[id]["client_socketid"]))

                else:
                    print("connection is closed")
                    sockets.remove(client_socket)
                    client_socket.close()
                    # we need to remove the mapping from the dictionary

                    ports = ports - 1
                    #print("number of ports in closing {}".format(ports))
                    # del mac_mapping[client_socket]
    except Exception as e:
        pass


def signal_handler(signum, frame):
    exit_event.set()
    for socket1 in sockets:
        sockets.remove(socket1)
        socket1.close()
    if server_socket in server_socketlst:
        server_socketlst.remove(server_socket)
    server_socket.close()
    try:
        os.remove(source_ip)
        os.remove(source_port)

    except OSError as e:
        pass
    sys.exit(0)


mac_mapping_lock = threading.Lock()


def time_thread_fun():
    try:
        while not exit_event.is_set():
            items = []
            mac_mapping1 = copy.copy(mac_mapping)

            with mac_mapping_lock:
                for id, values in mac_mapping1.items():
                    for key, value in values.items():
                        if key == 'time' and (time.time() - value) > 30.0:
                            items.append(id)
                            # mac_mapping[id]["mac_address"] = '0'
                            # del mac_mapping[id]

                            # here we need to remove the socket id from the mac_mapping dictionary and  if it becomes active(sends the data) we need to update it again
                for id in items:
                    del mac_mapping[id]
                time.sleep(1)
    except Exception as e:
        pass


def input_commands():
    try:
        while not exit_event.is_set():
            command = input()
            if command == "show mac_mapping":
                for key, value in mac_mapping.items():
                    mac_address = mac_mapping[key]["mac_address"]
                    ti = ((time.time()) - mac_mapping[key]['time'])
                    print("{}--> mac_address:{} , time:{}".format(key.fileno(), mac_address, ti))
            elif command == "quit":
                exit_event.set()
                for socket1 in sockets:
                    sockets.remove(socket1)
                    socket1.close()
                server_socketlst.remove(server_socket)
                server_socket.close()
                try:
                    os.remove(source_ip)
                    os.remove(source_port)

                except OSError as e:
                    pass
                sys.exit(0)
            else:
                print("please provide <show mac_mapping> to see the mac_mapping details and <quit> to close the bridge")
    except Exception as e:
        pass


def main():
    global num_ports, client_socket, server_socket, entry_i, source_ip, source_port, ports

    if len(sys.argv) == 3:
        lan_name = sys.argv[1]
        num_ports = int(sys.argv[2])
        ports=0
        signal.signal(signal.SIGINT, signal_handler)
        lan_ip_file = "." + lan_name + ".addr"
        lan_port = "." + lan_name + ".port"
        # list to hold sockets
        source_ip = ".ip_{}address.txt".format(lan_name)
        source_port = ".port_{}number.txt".format(lan_name)
        if os.path.exists(source_ip) and os.path.exists(source_port):
            print("lan already exists, try with other lan name")
            sys.exit(0)
        # to store mac address, port number and client socketid
        command_thread = threading.Thread(target=input_commands)
        time_thread = threading.Thread(target=time_thread_fun)
        time_thread.daemon = True
        command_thread.daemon = True
        signal.signal(signal.SIGINT, signal_handler)
        command_thread.start()
        time_thread.start()

        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socketlst.append(server_socket)
        server_socket.setblocking(False)
        server_socket.bind(('', 0))
        server_address, server_port = server_socket.getsockname()
        server_ip = socket.gethostbyname(socket.gethostname())
        # creating a symbolic link
        with open(source_ip, "w") as file:
            file.write(server_ip)
        with open(source_port, "w") as file:
            file.write(str(server_port))
        if os.path.islink(lan_ip_file):
            os.remove(lan_ip_file)
        if os.path.islink(lan_port):
            os.remove(lan_port)

        os.symlink(source_ip, lan_ip_file)
        os.symlink(source_port, lan_port)
        server_socket.listen(num_ports)
        accepts_thread = threading.Thread(target=accept_thread, args=(server_socket,))
        accepts_thread.daemon = True
        accepts_thread.start()
        accepts_thread.join()
        # command_thread.join()
        # time_thread.join()
        # sockets.append(server_socket)



    else:
        print("Please provide all the command line arguments")
        sys.exit(0)


if __name__ == "__main__":
    main()
